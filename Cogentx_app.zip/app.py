
import streamlit as st
from crewai import Agent, Task, Crew, Process
from langchain_openai import ChatOpenAI
from langchain_groq import ChatGroq
from langchain_anthropic import ChatAnthropic
from dotenv import load_dotenv
import os
from crewai_tools import *





load_dotenv()

def create_lmstudio_llm(model, temperature):
    api_base = os.getenv('LMSTUDIO_API_BASE')
    os.environ["OPENAI_API_KEY"] = "lm-studio"
    os.environ["OPENAI_API_BASE"] = api_base
    if api_base:
        return ChatOpenAI(openai_api_key='lm-studio', openai_api_base=api_base, temperature=temperature)
    else:
        raise ValueError("LM Studio API base not set in .env file")

def create_openai_llm(model, temperature):
    safe_pop_env_var('OPENAI_API_KEY')
    safe_pop_env_var('OPENAI_API_BASE')
    load_dotenv(override=True)
    api_key = os.getenv('OPENAI_API_KEY')
    api_base = os.getenv('OPENAI_API_BASE', 'https://api.openai.com/v1/')
    if api_key:
        return ChatOpenAI(openai_api_key=api_key, openai_api_base=api_base, model_name=model, temperature=temperature)
    else:
        raise ValueError("OpenAI API key not set in .env file")

def create_groq_llm(model, temperature):
    api_key = os.getenv('GROQ_API_KEY')
    if api_key:
        return ChatGroq(groq_api_key=api_key, model_name=model, temperature=temperature)
    else:
        raise ValueError("Groq API key not set in .env file")

def create_anthropic_llm(model, temperature):
    api_key = os.getenv('ANTHROPIC_API_KEY')
    if api_key:
        return ChatAnthropic(anthropic_api_key=api_key, model_name=model, temperature=temperature)
    else:
        raise ValueError("Anthropic API key not set in .env file")

def safe_pop_env_var(key):
    try:
        os.environ.pop(key)
    except KeyError:
        pass
        
LLM_CONFIG = {
    "OpenAI": {
        "create_llm": create_openai_llm
    },
    "Groq": {
        "create_llm": create_groq_llm
    },
    "LM Studio": {
        "create_llm": create_lmstudio_llm
    },
    "Anthropic": {
        "create_llm": create_anthropic_llm
    }
}

def create_llm(provider_and_model, temperature=0.1):
    provider, model = provider_and_model.split(": ")
    create_llm_func = LLM_CONFIG.get(provider, {}).get("create_llm")
    if create_llm_func:
        return create_llm_func(model, temperature)
    else:
        raise ValueError(f"LLM provider {provider} is not recognized or not supported")

def load_agents():
    agents = [
        
Agent(
    role="CEO Agent",
    backstory="Developed as the central decision-maker, the CEO Agent was designed to integrate external research and internal agent outputs. It was conceptualized to ensure a comprehensive and cohesive AI agent structure that reflects the user\u2019s needs.",
    goal="To aggregate responses from all subordinate agents, perform a final review, and integrate agent, task, and tool selections into a unified output.",
    allow_delegation=True,
    verbose=True,
    tools=[],
    llm=create_llm("OpenAI: gpt-4o-mini", 0.7)
)
            ,
        
Agent(
    role="Crew Agent",
    backstory="The Crew Agent was established to organize the collective workforce of the system. Its design supports dynamic reconfiguration and parallel task handling, ensuring that all agents operate in a coordinated, efficient manner.  \n\nyou need to create this crew according to the user requirments return this details \n\nProcess sequence, horizontal\nAgents : choose\nTasks: choose\nManager LLM :\nManager Agent :\nVerbous\nMemory\nCache\nPlanning\nMax req/min : 1000",
    goal="To maintain a real-time configuration of agents and tasks, manage process sequences, and support scheduling (planning) and memory caching.",
    allow_delegation=True,
    verbose=True,
    tools=[],
    llm=create_llm("OpenAI: gpt-4o-mini", 0.71)
)
            ,
        
Agent(
    role="Agent Creator Agent",
    backstory="This agent was designed to automate the instantiation of new agents with all necessary parameters. It ensures that each agent is properly configured from the outset, reducing manual overhead and potential configuration errors.",
    goal="To dynamically create and configure new agents so that they can be immediately integrated into the system\u2019s workflow.\n",
    allow_delegation=True,
    verbose=True,
    tools=[],
    llm=create_llm("OpenAI: gpt-4o-mini", 0.71)
)
            ,
        
Agent(
    role="Tool Selector Agent",
    backstory="Designed to map task requirements to available tools, the Tool Selector Agent dynamically chooses the best resources based on efficiency and relevance. Its development was driven by the need for a flexible, adaptive approach to tool integration.",
    goal="To analyze user requirements and task specifications and then select from the available toolset the most appropriate instruments to support each agent\u2019s operations.",
    allow_delegation=True,
    verbose=True,
    tools=[WebsiteSearchTool(), ScrapeWebsiteTool(), SerperDevTool(SERPER_API_KEY="8b62cc71180463c966dc123e51078eaedd9152c2")],
    llm=create_llm("OpenAI: gpt-4o-mini", 0.1)
)
            
    ]
    return agents

def load_tasks(agents):
    tasks = [
        
Task(
    description="Develop a complete crew configuration based on the following parameters:\nName: A unique identifier (for internal use only)\nProcess Sequence: Set to \"horizontal\" to enable parallel processing\nAgents: A selectable list of agents to be included\nTasks: A selectable list of tasks the crew will manage\nManager LLM: Specify the language model designated for crew management\nManager Agent: Define the supervising agent for the crew\nVerbose: Enable detailed logging for process transparency\nMemory: Activate persistent memory for state retention\nCache: Enable caching to speed up data retrieval\nPlanning: Incorporate planning capabilities for task scheduling\nMax req/min: Set to 1000 to regulate processing throughput",
    expected_output="A finalized crew configuration document (e.g., in JSON or YAML format) that accurately captures all specified parameters and is ready for validation and deployment within the multi-agent system.",
    agent=next(agent for agent in agents if agent.role == "Crew Agent"),
    async_execution=False
)
            ,
        
Task(
    description="Analyze the user\u2019s requirements and determine which tools from the following list are best suited to support the agents' operations. The task involves evaluating the functionality of each tool in the context of the system\u2019s needs, then selecting a subset that maximizes efficiency and relevance for tasks such as web scraping, file handling, code interpretation, and data processing.\nTools List:\nScrapeWebsiteTool\nSerperDevTool\nWebsiteSearchTool\nScrapeWebsiteToolEnhanced\nSeleniumScrapingTool\nScrapeElementFromWebsiteTool\nCustomApiTool\ncodeInterpreterTool\nCustomCodeInterpreterTool\nFileReadTool\nCustomFileWriteTool\nDirectorySearchTool\nDirectoryReadTool\nYoutubeVideoSearchTool\nYoutubeChannelSearchTool\nGithubSearchTool\nCodeDocsSearchTool\nYahooFinanceNewsTool\nTXTSearchTool\nCSVSearchTool\nCSVSearchToolEnhanced\nDOCXSearchTool\nEXASearchTool\nJSONSearchTool\nMDXSearchTool\nPDFSearchTool",
    expected_output="A finalized selection document (e.g., in JSON or YAML format) that lists the chosen tools along with a rationale for each selection, ensuring that all aspects of the user requirements (such as data collection, analysis, and report generation) are adequately supported.",
    agent=next(agent for agent in agents if agent.role == "Tool Selector Agent"),
    async_execution=False
)
            ,
        
Task(
    description="Create agent list according to user requiremtns must be meaningful ",
    expected_output="agent list",
    agent=next(agent for agent in agents if agent.role == "Agent Creator Agent"),
    async_execution=False
)
            ,
        
Task(
    description="Develop a set of individual tasks that define the responsibilities for each agent in the multi-agent system according to user requirements. This meta task breaks down the overall task creation into separate sub\u2010tasks\u2014one per agent\u2014and assigns each to the appropriate agent. Each sub\u2010task should detail the agent\u2019s role and expected outputs so that every part of the system is properly configured.",
    expected_output="A finalized task list (formatted in JSON, YAML, or a structured document) that includes the following sub\u2010tasks:\n\nCEO Agent Task: Define and document responsibilities (e.g., gathering user requirements, coordinating agents, aggregating responses).\nCrew Agent Task: Specify details for creating and managing crew information (e.g., process sequence, agent/task selection, manager configurations).\nAgent Creator Agent Task: Outline tasks to create new agent profiles including role, backstory, goal, delegation, verbosity, caching, LLM, tempracure, max iteration, and tool selection.\nTool Selector Agent Task: Determine and assign which tools (from the provided list) are necessary to support system tasks, based on user requirements.\nTask Definer Agent Task: Develop a structured list of tasks to be executed by the agents, complete with descriptions, expected outputs, and assignment details.\nSub-Tasks Details:\n\nSub-Task: Define CEO Agent Tasks\n\nCreate Task: Yes\nDescription: Outline tasks for the CEO Agent to collect user input, perform web research, and coordinate the overall agent structure.\nExpected Output: A detailed list of CEO Agent tasks covering requirement gathering, aggregation, and final validation.\nAgent: CEO Agent\nAsync Execution: No\nContext: Derived from direct user requirements and overall system design specifications.\nSub-Task: Define Crew Agent Tasks\n\nCreate Task: Yes\nDescription: Specify tasks for the Crew Agent to create crew information, including defining the process sequence (\"horizontal\"), selecting agents and tasks, and setting manager configurations (LLM and Manager Agent), along with verbose logging, memory, cache, planning, and max req/min (1000).\nExpected Output: A complete crew configuration document ready for deployment.\nAgent: Crew Agent\nAsync Execution: Yes\nContext: Based on user-provided crew details and system requirements.\nSub-Task: Define Agent Creator Agent Tasks\n\nCreate Task: Yes\nDescription: Define tasks for the Agent Creator Agent to generate new agent profiles. Each profile should include parameters such as role, backstory, goal, delegation capability, verbose setting, cache configuration, selected LLM (e.g., \"gpt-4\"), tempracure, max iteration, and a list of tools to be used.\nExpected Output: A set of agent profiles formatted as configuration documents (JSON or YAML).\nAgent: Agent Creator Agent\nAsync Execution: Yes\nContext: Combines user input, pre-existing templates (if available), and design specifications.\nSub-Task: Define Tool Selector Agent Tasks\n\nCreate Task: Yes\nDescription: Outline tasks for the Tool Selector Agent to analyze user requirements and select the appropriate tools from the provided list. The task should include evaluating tool functionalities (e.g., web scraping, file operations, code interpretation) and finalizing a tool selection that supports the agents\u2019 operations.\nExpected Output: A documented tool selection list with justifications for each chosen tool.\nAgent: Tool Selector Agent\nAsync Execution: Yes\nContext: Based on user requirements and tool performance data, as available.\nSub-Task: Define Task Definer Agent Tasks\n\nCreate Task: Yes\nDescription: Formulate tasks for the Task Definer Agent to create and organize all system tasks. This includes specifying task descriptions, expected outputs, agent assignments, and delineating execution contexts (both asynchronous and synchronous).\nExpected Output: A structured and prioritized list of system tasks that align with the overall workflow.\nAgent: Task Definer Agent\nAsync Execution: Yes\nContext: Informed by previous sub-task outputs and overall user requirements.",
    agent=next(agent for agent in agents if agent.role == "Tool Selector Agent"),
    async_execution=False
)
            ,
        
Task(
    description="Generate a detailed agent profile using the specified parameters. This task involves:\n\nSetting the Create Agent flag to initiate the creation process.\nDefining the Role of the agent (e.g., CEO Agent, Crew Agent, Agent Creator Agent, etc.).\nCrafting a Backstory that provides context and rationale for the agent\u2019s inclusion.\nEstablishing the Goal to outline the primary objectives the agent must achieve.\nIndicating whether the agent Allows Delegation of subtasks.\nEnabling Verbose mode for detailed logging and transparency.\nConfiguring Cache settings to enable temporary storage of intermediate results.\nSpecifying the LLM (for example, \"gpt-4\") to be used by the agent.\nSetting the Tempracure value to balance creativity and precision.\nDetermining the Max Iteration limit for processing or refinement cycles.\nProviding an interface to Select Tools that will be used to support the agent's tasks.",
    expected_output="A finalized agent profile document (formatted in JSON or YAML) that includes all the parameters listed above, ready for deployment within the multi-agent system.",
    agent=next(agent for agent in agents if agent.role == "Agent Creator Agent"),
    async_execution=False
)
            ,
        
Task(
    description="The CEO Agent must gather and review all details from the previous configuration tasks. This includes:\nCreate agent for customer support\nCrew Creation Details:\nName (unique identifier)\nProcess Sequence (\"horizontal\")\nSelected Agents\nSelected Tasks\nManager LLM\nManager Agent\nVerbose flag\nMemory and Cache settings\nPlanning capability\nMax req/min set to 1000\nTools List:\nA comprehensive list of available tools (e.g., ScrapeWebsiteTool, SerperDevTool, WebsiteSearchTool, etc.)\nAgent Definitions:\nFor each agent, verify parameters such as:\nCreate Agent flag\nRole\nBackstory\nGoal\nAllow Delegation\nVerbose setting\nCache configuration\nLLM selection\nTempracure value\nMax Iteration limit\nSelected Tools\nTask Definitions:\nFor each task in the system, ensure that details include:\nCreate Task flag\nDescription\nExpected Output\nAssigned Agent\nAsync Execution flag\nContext from Async Tasks\nContext from Sync Tasks\nThe CEO Agent must confirm that every element is properly configured, validate the interdependencies, and then output a final consolidated configuration document that encompasses all these details. This final output should be in a structured format (such as JSON or YAML) and ready for deployment.",
    expected_output="A comprehensive, validated configuration document that includes:\n\nCrew Configuration: Complete crew creation details.\nTools Selection: The full list of tools with the chosen ones clearly marked or justified.\nAgent List: Detailed agent profiles including all specified parameters.\nTask List: A complete list of tasks, along with their respective execution details and assignments.\nA final status report confirming that the CEO Agent has verified and integrated all the parts properly.",
    agent=next(agent for agent in agents if agent.role == "CEO Agent"),
    async_execution=False
)
            
    ]
    return tasks

def main():
    st.title("Cogentx")

    agents = load_agents()
    tasks = load_tasks(agents)
    crew = Crew(
        agents=agents, 
        tasks=tasks, 
        process="hierarchical", 
        verbose=True, 
        memory=True, 
        cache=True, 
        max_rpm=1000,
        manager_agent=next(agent for agent in agents if agent.role == "CEO Agent")
    )

    

    placeholders = {
        
    }
        with st.spinner("Running crew..."):
            try:
                result = crew.kickoff(inputs=placeholders)
                with st.expander("Final output", expanded=True):
                    if hasattr(result, 'raw'):
                        st.write(result.raw)                
                with st.expander("Full output", expanded=False):
                    st.write(result)
            except Exception as e:
                st.error(f"An error occurred: {str(e)}")

if __name__ == '__main__':
    main()
